/* Daycare Forms — fills the French daycare forms from one set of answers.
   Every position below was measured from the 2026 versions the office sent
   (Aug 5, 2026). If the office sends a new version of a form, its section here
   is the only thing that needs re-measuring. Coordinates are PDF points from
   the bottom-left corner of the page. */
(function (root) {
  'use strict';
  const PDFLib = root.PDFLib || (typeof require !== 'undefined' ? require('./vendor/pdf-lib.min.js') : null);
  const { PDFDocument, StandardFonts, PDFName, PDFHexString, PDFObjectCopier, TextAlignment, rgb } = PDFLib;

  const LETTER = [612, 792];
  const INK = rgb(0, 0, 0);   // black, like the rest of the form

  const TEMPLATES = {
    renseignements: 'templates/renseignements-2026.pdf',
    ententeBC: 'templates/entente-bc-2026.pdf',
    ententeMinistere: 'templates/entente-ministere-2026.pdf',
    contribution: 'templates/contribution-reduite-2026.pdf',
    fiche: 'templates/fiche-identification-en.pdf',
    assiduite: 'templates/fiche-assiduite-2026.pdf',
    attestation: 'templates/attestation-2026.pdf',
    integration: 'templates/plan-integration-2026.pdf',      // FO-5035, Plan d'intégration et bilan, 12 pages, fillable
    rapport: 'templates/rapport-professionnel-2026.pdf',     // FO-5036, Rapport professionnel, 7 pages, fillable
  };

  // ---------- small helpers ----------

  const s = v => (v == null ? '' : String(v)).trim();
  const join = (...parts) => parts.map(s).filter(Boolean).join(' ');
  const fullName = p => p ? join(p.first, p.last) : '';
  const hasPerson = p => !!(p && (s(p.first) || s(p.last)));

  // Stored dates are always YYYY-MM-DD (what <input type=date> gives).
  function dateParts(iso) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s(iso));
    return m ? { y: m[1], m: m[2], d: m[3] } : { y: '', m: '', d: '' };
  }
  const isoDate = iso => (dateParts(iso).y ? s(iso) : '');

  function addDays(iso, n) {
    const { y, m, d } = dateParts(iso);
    const dt = new Date(Date.UTC(+y, +m - 1, +d + n));
    return dt.toISOString().slice(0, 10);
  }

  // "514-555-1234" -> { area: '514', rest: '555-1234' }
  function splitPhone(p) {
    const digits = s(p).replace(/\D/g, '');
    if (digits.length === 10) return { area: digits.slice(0, 3), rest: digits.slice(3, 6) + '-' + digits.slice(6) };
    if (digits.length === 11 && digits[0] === '1') return splitPhone(digits.slice(1));
    return { area: '', rest: s(p) };
  }

  // "123 Avenue Example" -> { no: '123', street: 'Avenue Example' }
  function splitStreet(addr) {
    const m = /^\s*(\d+[A-Za-z]?(?:-\d+)?)[\s,]+(.*)$/.exec(s(addr));
    return m ? { no: m[1], street: m[2] } : { no: '', street: s(addr) };
  }

  const money = v => {
    const n = parseFloat(String(v).replace(',', '.').replace(/[^\d.]/g, ''));
    return isFinite(n) ? n.toFixed(2).replace('.', ',') + ' $' : '';
  };

  const DAYS_FR = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];

  // ---------- opening days, AD days, and the attendance amount ----------

  const pad2 = n => String(n).padStart(2, '0');
  const isoOf = (y, m, d) => y + '-' + pad2(m) + '-' + pad2(d);   // m is 1 to 12
  // 0 = Monday ... 6 = Sunday
  function weekdayIndex(iso) {
    const { y, m, d } = dateParts(iso);
    return (new Date(Date.UTC(+y, +m - 1, +d)).getUTCDay() + 6) % 7;
  }

  // Easter Sunday of a year (Gregorian calendar).
  function easterSunday(y) {
    const a = y % 19, b = Math.floor(y / 100), cc = y % 100;
    const d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3);
    const h = (19 * a + b - d - g + 15) % 30, i = Math.floor(cc / 4), k = cc % 4;
    const l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
    const month = Math.floor((h + l - 7 * m + 114) / 31), day = ((h + l - 7 * m + 114) % 31) + 1;
    return isoOf(y, month, day);
  }

  // The 10 predetermined closed days (AD) listed in the contract, for one year.
  // Returns { 'YYYY-MM-DD': 'name' }.
  const adCache = {};
  function adDays(y) {
    if (adCache[y]) return adCache[y];
    const easter = easterSunday(y);
    const firstMonday = month => 1 + ((7 - weekdayIndex(isoOf(y, month, 1))) % 7);
    const out = {};
    out[isoOf(y, 1, 1)] = "Jour de l'An";
    out[addDays(easter, -2)] = 'Vendredi de Pâques';
    out[addDays(easter, 1)] = 'Lundi de Pâques';
    out[isoOf(y, 5, 24 - weekdayIndex(isoOf(y, 5, 24)))] = 'Journée nationale des patriotes';   // the Monday before May 25
    out[isoOf(y, 6, 24)] = 'Fête nationale du Québec';
    out[isoOf(y, 7, 1)] = 'Fête du Canada';
    out[isoOf(y, 9, firstMonday(9))] = 'Fête du Travail';
    out[isoOf(y, 10, firstMonday(10) + 7)] = "L'Action de Grâce";                                 // second Monday of October
    out[isoOf(y, 12, 25)] = 'Jour de Noël';
    out[isoOf(y, 12, 26)] = 'Lendemain de Noël';
    return (adCache[y] = out);
  }

  // The opening hours that apply to a child: the night table for a night child.
  const hoursFor = (S, c) => ((c && c.shift === 'night' && S.nightHours) ? S.nightHours : (S.hours || []));

  // True for each weekday (Monday first) the child's daycare is closed.
  const closedWeekdays = (S, c) => [0, 1, 2, 3, 4, 5, 6].map(i => {
    const h = hoursFor(S, c)[i];
    return !h || !s(h.open) || /ferm|closed/i.test(s(h.open));
  });

  // What the attendance sheet shows for a closed day: F (regular closed day), AD (legal
  // closed day), or '' when the daycare is open. An AD that lands on a regular closed day
  // is just F: no extra day is closed to make up for it.
  function dayCode(S, c, iso) {
    if (closedWeekdays(S, c)[weekdayIndex(iso)]) return 'F';
    return adDays(+dateParts(iso).y)[iso] ? 'AD' : '';
  }

  // Daily rate × the days the child was booked and the daycare was open, over the two weeks.
  function attendanceAmount(S, c, monday) {
    if (c.contribution === 'exempt') return null;
    const rate = parseFloat(String(S.rate).replace(',', '.'));
    if (!isFinite(rate)) return null;
    let n = 0;
    for (let i = 0; i < 14; i++) {
      const iso = addDays(monday, i);
      if (dayCode(S, c, iso)) continue;
      if (!(c.days || [])[weekdayIndex(iso)]) continue;
      if (s(c.startDate) && iso < c.startDate) continue;
      if (s(c.leftDate) && iso > c.leftDate) continue;
      n++;
    }
    return n ? rate * n : null;
  }

  // What the parent pays per payment: daily rate × days a week × weeks per payment.
  function paymentAmount(S, c) {
    if (c.contribution === 'exempt') return null;
    const rate = parseFloat(String(S.rate).replace(',', '.'));
    const days = (c.days || []).filter(Boolean).length;
    const weeks = { weekly: 1, biweekly: 2 }[S.payFrequency];
    return isFinite(rate) && days && weeks ? rate * days * weeks : null;
  }

  // Which parent pays and signs the contribution form.
  const payerOf = c => (c.payer === 'B' && hasPerson(c.parentB)) ? c.parentB : c.parentA;

  // ---------- drawing on flat (non-fillable) forms ----------

  // On the flat forms every answer goes into a real typing box (and every choice
  // into a real tick box), so the finished file can still be corrected by hand.
  function writer(doc, page, font) {
    const form = doc.getForm();
    let n = 0;
    const id = () => 'df_' + page.ref.objectNumber + '_' + (n++);
    // Text that would overflow its blank line is shrunk until it fits.
    function fit(text, size, maxW) {
      let sz = size;
      while (text && maxW && sz > 5 && font.widthOfTextAtSize(text, sz) > maxW) sz -= 0.5;
      return sz;
    }
    function box(text, x, y, w, size, align) {
      text = s(text);
      const sz = fit(text, size, w - 2);
      const f = form.createTextField(id());
      if (text) f.setText(text);
      f.addToPage(page, { x, y: y - 2, width: w, height: size + 5, font, textColor: INK, borderWidth: 0, borderColor: undefined, backgroundColor: undefined });
      f.setFontSize(sz);
      if (align) f.setAlignment(align);
    }
    return {
      at(text, x, y, maxW, size = 10) { box(text, x, y, maxW || 120, size); },
      centre(text, x0, x1, y, size = 10) { box(text, x0, y, x1 - x0, size, TextAlignment.Center); },
      tick(cx, cy, size = 12, on = true) {
        const f = form.createCheckBox(id());
        const w = size * 0.95;
        f.addToPage(page, { x: cx - w / 2, y: cy - w / 2, width: w, height: w, textColor: INK, borderWidth: 0, borderColor: undefined, backgroundColor: undefined });
        if (on) f.check();
      },
    };
  }

  // ---------- filling fillable forms ----------

  function formFiller(doc) {
    const form = doc.getForm();
    const fieldOf = name => { try { return form.getField(name); } catch (e) { return null; } };
    return {
      form,
      text(name, value) {
        const v = s(value); if (!v) return;
        const f = fieldOf(name); if (!f || !f.setText) return;
        const max = f.getMaxLength && f.getMaxLength();
        try { f.setText(max ? v.slice(0, max) : v); } catch (e) { /* leave blank rather than fail the whole file */ }
      },
      // Ticks the n-th box of a button field (works for radio groups and for
      // check boxes that share one name). Done at the PDF level because some
      // government forms give their options names pdf-lib cannot decode.
      // n counts boxes in reading order (top to bottom, then left to right),
      // because the order stored inside the file is not always the order on the page.
      pick(name, n) {
        const f = fieldOf(name); if (!f) return;
        const all = f.acroField.getWidgets();
        const pos = w => { const r = w.getRectangle(); return { x: r.x, y: r.y + r.height }; };
        const widgets = all.slice().sort((a, b) => {
          const pa = pos(a), pb = pos(b);
          return Math.abs(pa.y - pb.y) > 3 ? pb.y - pa.y : pa.x - pb.x;
        });
        if (!widgets[n]) return;
        const on = widgets[n].getOnValue();
        if (!on) return;
        f.acroField.dict.set(PDFName.of('V'), on);
        all.forEach(w => w.setAppearanceState(w === widgets[n] ? on : PDFName.of('Off')));
      },
      check(name, yes = true) { if (yes) this.pick(name, 0); },
    };
  }

  // Draws the typed answers into the boxes; the boxes stay editable.
  async function finish(doc) {
    const font = await doc.embedFont(StandardFonts.Helvetica);
    try { doc.getForm().updateFieldAppearances(font); } catch (e) { /* appearances already present */ }
  }

  // ---------- the forms ----------

  // Formulaire de renseignements MF 2026 — letter, 1 page, flat.
  async function fillRenseignements(doc, S, c) {
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const w = writer(doc, doc.getPage(0), font);
    w.at(fullName(S.rsge), 326, 655, 185);
    const col = (p, L) => {
      p = p || {};
      w.at(p.last, L.nom, 571.5, 165);
      w.at(p.first, L.prenom, 554.5, 150);
      w.at(join(p.street, p.apt ? 'app. ' + p.apt : ''), L.adresse, 538, 150);
      w.at(p.city, L.ville, 521, 172);
      w.at(p.postal, L.postal, 504.5, 125);
      const h = splitPhone(p.homeTel), t = splitPhone(p.workTel);
      w.centre(h.area, L.homeArea[0], L.homeArea[1], 487.5, 9);
      w.at(h.rest, L.home, 487.5, 74);
      w.centre(t.area, L.workArea[0], L.workArea[1], 471, 9);
      w.at(t.rest, L.work, 471, 89);
      w.at(p.email, L.email, 454, 135, 9);
      w.at(p.sin, L.sin, 437.5, 127);
    };
    col(c.parentA, { nom: 103, prenom: 118, adresse: 119, ville: 97, postal: 139, homeArea: [163.7, 184.5], home: 196, workArea: [146.4, 167.1], work: 178.5, email: 133, sin: 141.5 });
    col(c.parentB, { nom: 351, prenom: 366, adresse: 367, ville: 345, postal: 387, homeArea: [411.6, 432.4], home: 444, workArea: [394.3, 415.0], work: 426.5, email: 381, sin: 389.5 });
    w.at(c.child.first, 181, 387.5, 96);
    const dob = dateParts(c.child.dob);
    w.centre(dob.d, 434.9, 457.5, 387.5); w.centre(dob.m, 467.8, 490.4, 387.5); w.centre(dob.y, 500.8, 523.4, 387.5, 9);
    const st = dateParts(c.startDate);
    w.centre(st.d, 282.1, 304.7, 320.5); w.centre(st.m, 315.1, 337.7, 320.5); w.centre(st.y, 348.0, 370.7, 320.5, 9);
    const boxes = [146.5, 182.5, 218.5, 254.5, 283.3, 319.3, 355.3];
    boxes.forEach((x, i) => w.tick(x, 190.3, 14, !!(c.days || [])[i]));
  }

  // Entente pour garde BC 2026 — A4, 2 pages, flat.
  async function fillEntenteBC(doc, S, c) {
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const p1 = writer(doc, doc.getPage(0), font);
    const p2 = writer(doc, doc.getPage(1), font);
    const parent = payerOf(c);
    const block = (p, x) => {
      // x = { nom, prenom, adresse, ville, postal, tel, cell, autre } start positions, right edge per line
      p1.at(p.last, x.nom[0], 681, x.nom[1] - x.nom[0]);
      p1.at(p.first, x.prenom[0], 662, x.prenom[1] - x.prenom[0]);
      p1.at(join(p.street, p.apt ? 'app. ' + p.apt : ''), x.adresse[0], 643, x.adresse[1] - x.adresse[0], 9);
      p1.at(p.city, x.ville[0], 624, x.ville[1] - x.ville[0]);
      p1.at(p.postal, x.postal[0], 605, x.postal[1] - x.postal[0]);
      p1.at(p.homeTel || p.phone, x.tel[0], 586, x.tel[1] - x.tel[0]);
      p1.at(p.cell, x.cell[0], 567, x.cell[1] - x.cell[0]);
      p1.at(p.other || p.workTel, x.autre[0], 548, x.autre[1] - x.autre[0], 9);
    };
    block(S.rsge, { nom: [57, 199], prenom: [69.5, 200], adresse: [70.5, 196], ville: [57, 149], postal: [87.5, 169], tel: [107, 189], cell: [78.5, 176], autre: [60, 174] });
    block(hasPerson(parent) ? parent : {}, { nom: [332.5, 475], prenom: [345, 476], adresse: [346, 472], ville: [332.5, 425], postal: [363, 444], tel: [383, 464], cell: [354, 452], autre: [336, 450] });

    p1.at(c.child.last, 99, 506, 152);
    p1.at(c.child.first, 346, 506, 147);
    p1.at(isoDate(c.child.dob), 111, 487, 142);
    p1.tick(419.9, 490.9, 11, c.child.sex === 'M');
    p1.tick(463.4, 490.9, 11, c.child.sex === 'F');

    const cols1 = [107.5, 174.6, 241.6, 308.6, 375.7, 442.7, 509.6, 576.7];
    hoursFor(S, c).forEach((h, i) => {
      p1.centre(/^(closed|ferm)/i.test(s(h.open)) ? 'Fermé' : h.open, cols1[i], cols1[i + 1], 354.6, 9);
      p1.centre(h.close, cols1[i], cols1[i + 1], 338.7, 9);
    });
    p1.at(S.vacation, 25, 126, 545, 9);
    p1.tick(51.4, 79.3, 12, S.claimClosure === true);
    p1.tick(199.8, 79.4, 12, S.claimClosure === false);

    const nDays = (c.days || []).filter(Boolean).length;
    p2.centre(nDays ? String(nDays) : '', 307, 329, 797.5);
    p2.tick(27.4, 788.8, 12, c.contribution !== 'exempt');
    p2.tick(27.4, 771.8, 12, c.contribution === 'exempt');
    p2.centre(c.contribution !== 'exempt' ? money(S.rate) : '', 372.5, 411.1, 783.5, 9);
    p2.centre(S.overtimeRate, 51.3, 89.9, 726.5, 9);
    p2.centre(S.overtimeUnit, 149.4, 182.5, 726.5, 9);

    const cols2 = [112.5, 177.5, 242.4, 307.4, 372.3, 437.4, 502.3, 567.4];
    for (let i = 0; i < 7; i++) {
      const on = !!(c.days || [])[i];
      p2.centre(on ? c.arrive : '', cols2[i], cols2[i + 1], 632, 9);
      p2.centre(on ? c.depart : '', cols2[i], cols2[i + 1], 616, 9);
    }

    // Amount on the line for how often parents pay; "cheques payable to" stays blank (cash).
    const amt = paymentAmount(S, c);
    p2.centre(amt != null && S.payFrequency === 'weekly' ? money(amt) : '', 53.1, 91.7, 573.7, 8);
    p2.centre(amt != null && S.payFrequency === 'biweekly' ? money(amt) : '', 155.9, 199.9, 573.7, 8);
    p2.centre('', 306.9, 334.4, 573.7, 8);
    p2.at(S.payMethod === 'cheque' ? fullName(S.rsge) : '', 212, 561, 124);
    p2.centre(isoDate(c.signDate), 19.8, 151.8, 144, 10);   // Date and Lieu by the RSGE signature
    p2.centre(c.signPlace, 196.8, 316.9, 144, 10);
    p2.centre(isoDate(c.signDate), 19.8, 151.8, 90.5, 10);  // Date and Lieu by the parent signature
    p2.centre(c.signPlace, 196.8, 316.9, 90.5, 10);
    p2.centre(isoDate(c.startDate), 166.5, 249.1, 212.5, 9);
    p2.centre(isoDate(c.endDate), 262.1, 333.8, 212.5, 9);
  }

  // Entente de services de garde éducatifs subventionnés (Ministère) — legal size, 5 pages, fillable.
  async function fillEntenteMinistere(doc, S, c) {
    const f = formFiller(doc);
    const r = S.rsge;
    const rs = splitStreet(r.street);
    f.text('S1_Nom_Famille', fullName(r));
    f.text('S1_Numero', rs.no); f.text('S1_Rue', rs.street); f.text('S1_Appartement', r.apt);
    f.text('S1_Ville', r.city); f.text('S1_Province', 'Québec'); f.text('S1_Code_Postal', r.postal);
    const person = (p, suffix) => {
      if (!hasPerson(p)) return;
      const st = splitStreet(p.street);
      f.text('S1_Nom_Famille_' + suffix, p.last); f.text('S1_Prenom_' + suffix, p.first);
      f.text('S1_Numero_' + suffix, st.no); f.text('S1_Rue_' + suffix, st.street); f.text('S1_Appartement_' + suffix, p.apt);
      f.text('S1_Ville_' + suffix, p.city); f.text('S1_Province_' + suffix, 'Québec'); f.text('S1_Code_Postal_' + suffix, p.postal);
    };
    person(c.parentA, '02');
    person(c.parentB, '03');
    f.text('S1_Nom_Parent', fullName(payerOf(c)));
    f.text('S1_Nom_Famille_04', c.child.last); f.text('S1_Prenom_04', c.child.first);
    f.text('S1_Date_Naissance', isoDate(c.child.dob));

    f.text('S2_Heure_Collation_Matin', S.snackAM); f.text('S2_Heure_Collation_PM', S.snackPM); f.text('S2_Heure_Repas_Midi', S.lunch);
    hoursFor(S, c).forEach((h, i) => {
      if (/ferm|closed/i.test(s(h.open))) return;
      f.text('S2.2_Periode_Habituelle_Debut_ligne_' + (i + 1), h.open);
      f.text('S2.2_Periode_Habituelle_Fin_ligne_' + (i + 1), h.close);
    });
    if (S.claimClosure === true) f.check('S2.3_Reclamation');
    const dayKey = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
    (c.days || []).forEach((on, i) => {
      if (!on) return;
      f.text('S3.1_Besoin_Garde_' + dayKey[i] + '_De', c.arrive);
      f.text('S3.1_Besoin_Garde_' + dayKey[i] + '_A', c.depart);
    });
    if (c.contribution === 'exempt') f.check('S4.1_Exemption_Paiement');
    const amt = paymentAmount(S, c);
    const freq = { weekly: 0, biweekly: 1, monthly: 2 }[S.payFrequency];
    if (c.contribution !== 'exempt' && freq != null) {
      f.pick('S4.2_Type_Versement', freq);
      if (amt != null) f.text('S4.2_Montant_Versement', amt.toFixed(2).replace('.', ','));
    }
    const how = { cheque: 0, preauthorized: 1, cash: 2 }[S.payMethod];
    if (c.contribution !== 'exempt' && how != null) f.pick('S4.2_Type_Paiement', how);
    f.text('S4.1_Date-Debut_Prestation', isoDate(c.startDate));
    f.text('S8_Date_Frequentation_1', isoDate(c.startDate));
    f.text('S8_Date_Frequentation_2', isoDate(c.endDate));
    ['S14_Date_Signature_1', 'S14_Date_Signature_2', 'S14_Date_Signature_3'].forEach(n => f.text(n, isoDate(c.signDate)));
    ['S14_Lieu_Signature_1', 'S14_Lieu_Signature_2', 'S14_Lieu_Signature_3'].forEach(n => f.text(n, c.signPlace));
    await finish(doc);
  }

  // Demande d'admissibilité à la contribution réduite 2026 (Ministère) — letter, 4 pages, fillable.
  // Note: the government swapped two field names — "Firstname1" sits in the last-name (Nom) box.
  async function fillContribution(doc, S, c) {
    const f = formFiller(doc);
    const p = payerOf(c);
    if (hasPerson(p)) {
      f.text('S1_Parent_Firstname1', p.last);
      f.text('S1_Parent_Lastname1', p.first);
      f.text('S1_Parent_NAS1', p.sin);
      f.text('S1_Address_Street1', p.street); f.text('S1_Address_Apartment1', p.apt);
      f.text('S1_Address_City1', p.city); f.text('S1_Address_Province1', 'Québec'); f.text('S1_Address_Postalcode1', p.postal);
      f.text('S1_Tel_Home_Number1', p.homeTel); f.text('S1_Tel_Work_Number1', p.workTel);
      f.text('S1_Courriel', p.email);
      f.text('S1_Lien_1', p.relation);
    }
    if (c.citizen === true) f.pick('S1_Citoyennete', 0);
    if (c.citizen === false) f.pick('S1_Citoyennete', 1);
    f.text('S1_Nom_1', c.child.last); f.text('S1_Prenom_1', c.child.first);
    f.text('S1_Date_Naissance_1', isoDate(c.child.dob));
    f.text('S2_Date_journee_1', isoDate(c.startDate));
    if (c.benefits === true) { f.pick('S3_Prestation', 0); f.text('S31_Date_Signature', isoDate(c.signDate)); }
    if (c.benefits === false) f.pick('S3_Prestation', 1);
    if (c.prevContribution === true) f.pick('S4_Contribution', 0);
    if (c.prevContribution === false) f.pick('S4_Contribution', 1);
    f.text('S5_Date_Signature', isoDate(c.signDate));
    // Page 3 — documents attached (the birth certificates and the agreement always go in).
    f.check('S5_Doc_1'); f.check('S5_Doc_2'); f.check('S5_Doc_6');
    if (c.citizen === false) {
      f.check('S5_Doc_3');
      if (c.status !== '' && c.status != null) f.pick('S5_Status', +c.status);
    }
    if (c.benefits === true) f.check('S5_Doc_4');
    if (c.prevContribution === true) f.check('S5_Doc_5');
    // Page 4 — the coordinating office's page, prefilled the way the office expects.
    f.text('S4_Nom_Titulaire', S.bcName); f.text('S4_No_Division', S.division);
    f.text('S4_Nom', S.rsge.last); f.text('S4_Prenom', S.rsge.first);
    f.text('S7_Nom_1', c.child.last); f.text('S7_Prenom_1', c.child.first);
    f.text('S7_Date_Deb_Garde_1', isoDate(c.startDate));
    f.text('S7_Date_Decision_1', isoDate(c.decisionDate || c.signDate));
    f.text('S7_Date_Signature', isoDate(c.decisionDate || c.signDate));
    // The RSGE fills this page herself: the request is accepted, and for families on
    // social assistance the exemption answer follows the space type.
    f.pick('S6_Decision', 0);
    if (c.benefits === true) f.pick('S7_Paiement', c.contribution === 'exempt' ? 0 : 1);
    await finish(doc);
  }

  // Fiche d'identification — Moshe's English translation, letter, 2 pages, fillable.
  // Only the identification part is filled; the parents write the health part by hand.
  async function fillFiche(doc, S, c) {
    const f = formFiller(doc);
    f.text('full_name', join(c.child.first, c.child.last));
    const dob = dateParts(c.child.dob);
    f.text('dob_day', dob.d); f.text('dob_month', dob.m); f.text('dob_year', dob.y);
    const home = c.parentA && c.parentA.street ? c.parentA : c.parentB || {};
    f.text('address', join(home.street, home.apt ? 'apt ' + home.apt + ',' : (home.street ? ',' : ''), home.city, home.postal).replace(' ,', ','));
    f.text('phone', splitPhone(home.homeTel).rest);
    const rows = { 'Mère': 0, 'Père': 1 };
    const used = new Set();
    [c.parentA, c.parentB].forEach(p => {
      if (!hasPerson(p)) return;
      let row = rows[p.relation];
      if (row == null || used.has(row)) row = 2;
      if (used.has(row)) return;
      used.add(row);
      f.text('resp_name_' + row, fullName(p));
      f.text('resp_home_' + row, p.homeTel || p.cell);
      f.text('resp_work_' + row, p.workTel);
    });
    f.text('provider_name_ref', fullName(S.rsge));
    await finish(doc);
  }

  // Fiche d'assiduité 2026 — A4, 1 page, flat. Names and week dates only.
  async function fillAssiduite(doc, S, c, weekStart) {
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const w = writer(doc, doc.getPage(0), font);
    w.at(join(c.child.first, c.child.last), 150, 644, 400);
    w.at(fullName(payerOf(c)), 150, 626.5, 400);
    w.at(fullName(S.rsge), 150, 609, 400);
    w.at(c.leftDate && c.leftDate <= addDays(weekStart, 13) ? isoDate(c.leftDate) : '', 150, 591.5, 400);
    w.centre(weekStart, 35.4, 117.6, 325.5, 9);
    w.centre(addDays(weekStart, 7), 35.4, 117.6, 308, 9);
    // F (regular closed days) and AD (legal closed days), one code per day, in the first of the
    // day's two small boxes. Columns are Monday to Sunday, so line the dates up on the Monday.
    const monday = addDays(weekStart, -weekdayIndex(weekStart));
    const edges = [117.6, 149.2, 180.9, 212.5, 244.1, 275.8, 307.5, 339.1, 370.7, 402.4, 434.0, 465.6, 497.3, 529.0, 560.6];
    [325.5, 308].forEach((y, wk) => {
      for (let d = 0; d < 7; d++) {
        const code = dayCode(S, c, addDays(monday, wk * 7 + d));
        if (code) w.centre(code, edges[2 * d], edges[2 * d + 1], y, 9);
      }
    });
    // Payment confirmation and signature dates, laid out the way the office's sheets are:
    // the second row is the second week, paid and signed on that week's Friday.
    // The amount paid is the rate times the open days booked over both weeks.
    const friday = addDays(weekStart, 11);
    const amt = attendanceAmount(S, c, monday);
    const cols = [35.4, 166.9, 298.5, 430.1, 561.5];
    [241, 223.5].forEach((y, row) => {
      const vals = row === 1 ? [addDays(weekStart, 7), friday, amt != null ? money(amt) : '', ''] : ['', '', '', ''];
      vals.forEach((v, i) => w.centre(v, cols[i], cols[i + 1], y, 9));
    });
    w.centre(friday, 447.6, 560.8, 167, 9);   // Date by the RSGE signature
    w.centre(friday, 447.6, 560.8, 96, 9);    // Date by the parent signature
  }

  // Attestation des services de garde fournis 2026 — letter, 3 copies, fillable.
  // The three pages share their boxes, so filling once fills all three. Day counts stay blank.
  async function fillAttestation(doc, S, c) {
    const f = formFiller(doc);
    const comb = iso => isoDate(iso).replace(/-/g, '');   // these date boxes take 8 digits, one per square
    const p = payerOf(c), r = S.rsge;
    if (hasPerson(p)) { f.text('S1_NomFamille1', p.last); f.text('S1_Prenom1', p.first); }
    f.text('S2_1_NomFamille1', c.child.last); f.text('S2_1_Prenom1', c.child.first);
    f.text('S2_1_DateNaissance1', comb(c.child.dob));
    f.text('S3_1_DateDebut1', comb(c.startDate));
    f.text('S3_1_DateFin1', comb(c.leftDate));
    f.text('S4_2_Services1', r.last); f.text('S4_2_DivisionNom1', r.first);
    f.text('S4_2_Address1', join(r.street, r.apt ? 'app. ' + r.apt : ''));
    f.text('S4_2_Adresse3', join(r.city + ',', 'Québec'));
    f.text('S4_2_Telephone1', r.phone); f.text('S4_2_CodePostal1', r.postal);
    f.text('S4_2_Office1', S.bcName);
    f.text('S5_NomFamille1', r.last); f.text('S5_Prenom1', r.first);
    f.check('S4_Case2');
    f.text('S5_DateAttestation1', comb(c.attestDate));
    await finish(doc);
  }

  // ---------- assembling the printable file ----------

  async function loadTemplate(load, key) {
    return PDFDocument.load(await load(TEMPLATES[key]), { ignoreEncryption: true, updateMetadata: false });
  }

  // Copies every page of each filled form onto letter paper (shrinking A4 and
  // legal pages evenly to fit), and adds a blank page after any form that ends
  // on a front side, so double-sided printing never puts two forms on one sheet.
  // The typing boxes come along and stay editable: each form's boxes get a
  // prefix (f1_, f2_…) so two copies of the same form never share a box.
  async function assemble(docs, { duplex = true } = {}) {
    const out = await PDFDocument.create();
    const acro = out.catalog.getOrCreateAcroForm();
    const DR = PDFName.of('DR'), FONT = PDFName.of('Font'), T = PDFName.of('T'), PARENT = PDFName.of('Parent'), ANNOTS = PDFName.of('Annots');
    const outFonts = out.context.obj({});
    acro.dict.set(DR, out.context.obj({ Font: outFonts }));
    for (let k = 0; k < docs.length; k++) {
      const src = docs[k];
      await finish(src);   // draw every box's text with its final alignment and size
      // Fonts the boxes use when someone types into them later.
      const srcAcro = src.catalog.getAcroForm();
      const srcDR = srcAcro && srcAcro.dict.lookup(DR);
      const srcFonts = srcDR && srcDR.lookup(FONT);
      if (srcFonts) {
        const copier = PDFObjectCopier.for(src.context, out.context);
        srcFonts.entries().forEach(([name, ref]) => { if (!outFonts.has(name)) outFonts.set(name, copier.copy(ref)); });
      }
      const copied = await out.copyPages(src, src.getPageIndices());
      const roots = new Set();
      copied.forEach(page => {
        out.addPage(page);
        const box = page.getMediaBox();
        const sc = Math.min(LETTER[0] / box.width, LETTER[1] / box.height, 1);
        const dx = (LETTER[0] - box.width * sc) / 2 - box.x * sc, dy = (LETTER[1] - box.height * sc) / 2 - box.y * sc;
        if (sc < 1) page.scale(sc, sc);   // content, boxes and page size together
        page.translateContent(dx, dy);
        const annots = page.node.lookup(ANNOTS);
        if (annots) {
          annots.asArray().forEach(ref => {
            const a = out.context.lookup(ref);
            if (!a || !a.lookup) return;
            const r = a.lookup(PDFName.of('Rect'));
            if (r) { const v = r.asArray().map(n => n.asNumber()); a.set(PDFName.of('Rect'), out.context.obj([v[0] + dx, v[1] + dy, v[2] + dx, v[3] + dy])); }
            if (a.lookup(PDFName.of('Subtype')) !== PDFName.of('Widget')) return;
            let rootRef = ref, node = a;
            while (node.get(PARENT)) { rootRef = node.get(PARENT); node = out.context.lookup(rootRef); }
            roots.add(rootRef);
          });
        }
        page.setMediaBox(0, 0, LETTER[0], LETTER[1]);
        page.setCropBox(0, 0, LETTER[0], LETTER[1]);
        page.setTrimBox(0, 0, LETTER[0], LETTER[1]);
        page.setBleedBox(0, 0, LETTER[0], LETTER[1]);
        page.setArtBox(0, 0, LETTER[0], LETTER[1]);
      });
      roots.forEach(ref => {
        const field = out.context.lookup(ref);
        const t = field.lookup(T);
        field.set(T, PDFHexString.fromText('f' + (k + 1) + '_' + (t ? t.decodeText() : 'box')));
        acro.addField(ref);
      });
      if (duplex && copied.length % 2 === 1 && k < docs.length - 1) out.addPage(LETTER);
    }
    return out.save();
  }

  async function registrationPackage(load, S, c) {
    const order = [['ententeBC', fillEntenteBC]];
    if (c.includeMinistere) order.push(['ententeMinistere', fillEntenteMinistere]);
    order.push(['renseignements', fillRenseignements], ['contribution', fillContribution], ['fiche', fillFiche]);
    const docs = [];
    for (const [key, fill] of order) {
      const doc = await loadTemplate(load, key);
      await fill(doc, S, c);
      docs.push(doc);
    }
    return assemble(docs);
  }

  // Allocation pour l'intégration en service de garde: Plan d'intégration et bilan (FO-5035).
  // Only the identification and the writer's name are filled; the plan itself is for the provider and the parent.
  async function fillIntegration(doc, S, c) {
    const f = formFiller(doc);
    f.text('S1_Nom_Enfant', join(c.child.first, c.child.last));
    f.text('S1_Date_Naissance', isoDate(c.child.dob));
    f.text('S1_Nom_Tuteur1', fullName(c.parentA));
    if (hasPerson(c.parentB)) f.text('S1_Nom_Tuteur2', fullName(c.parentB));
    f.text('S1_Nom_Prestataire', fullName(S.rsge));
    f.text('S1_Nom_BC', S.bcName);
    f.text('S2_Redacteur', fullName(S.rsge));
    await finish(doc);
  }

  // Rapport professionnel (FO-5036): section 2 identification and the RSGE's name in section 3.
  // The professional's own part, the parent's choices and all signatures stay blank.
  async function fillRapport(doc, S, c) {
    const f = formFiller(doc);
    const r = S.rsge;
    const addr = p => join(p.street, p.apt ? 'app. ' + p.apt : '');
    f.text('S2_Nom_Enfant', join(c.child.first, c.child.last));
    f.text('S2_Date_Naissance', isoDate(c.child.dob));
    [[c.parentA, '1'], [c.parentB, '2']].forEach(([p, n]) => {
      if (!hasPerson(p)) return;
      f.text('S2_Tuteur_Nom' + n, fullName(p)); f.text('S2_Tuteur_Adresse' + n, addr(p));
      f.text('S2_Tuteur_Ville' + n, p.city); f.text('S2_Tuteur_Province' + n, 'Québec'); f.text('S2_Tuteur_CodePostal' + n, p.postal);
      f.text('S2_Tuteur_Courriel' + n, p.email); f.text('S2_Tuteur_Telephone' + n, p.homeTel || p.workTel); f.text('S2_Tuteur_Cellulaire' + n, p.cell);
    });
    f.text('S2_Prestataire_Nom1', fullName(r)); f.text('S2_Prestataire_Adresse1', addr(r));
    f.text('S2_Prestataire_Ville1', r.city); f.text('S2_Prestataire_Province1', 'Québec'); f.text('S2_Prestataire_CodePostal1', r.postal);
    f.text('S2_Prestataire_Telephone1', r.phone || r.cell);
    ['S3_B_Nom1', 'S3_C_Nom1', 'S3_E_Nom1'].forEach(k => f.text(k, fullName(r)));
    await finish(doc);
  }

  // The two disability forms are only made for children with "Child has a disability" ticked.
  const DISABILITY_FORMS = ['integration', 'rapport'];

  // Any mix of forms for any mix of children, in one file: child by child, the ticked forms in the usual order.
  const FORM_FILLERS = { ententeBC: fillEntenteBC, ententeMinistere: fillEntenteMinistere, renseignements: fillRenseignements, contribution: fillContribution, fiche: fillFiche, integration: fillIntegration, rapport: fillRapport };
  async function makeForms(load, S, children, keys) {
    const docs = [];
    for (const c of children) {
      for (const key of Object.keys(FORM_FILLERS)) {
        if (!keys.includes(key)) continue;
        if (DISABILITY_FORMS.includes(key) && !c.disability) continue;
        const doc = await loadTemplate(load, key);
        await FORM_FILLERS[key](doc, S, c);
        docs.push(doc);
      }
    }
    if (!docs.length) throw new Error('Nothing to make. The integration plan and the professional\'s report are only made for children with "Child has a disability" ticked.');
    return assemble(docs);
  }

  async function attendanceSheets(load, S, children, weekStart) {
    const docs = [];
    for (const c of children) {
      const doc = await loadTemplate(load, 'assiduite');
      await fillAssiduite(doc, S, c, weekStart);
      docs.push(doc);
    }
    return assemble(docs, { duplex: false });   // printed single-sided
  }

  async function attestation(load, S, c) {
    const doc = await loadTemplate(load, 'attestation');
    await fillAttestation(doc, S, c);
    return assemble([doc]);
  }

  const api = { TEMPLATES, registrationPackage, makeForms, attendanceSheets, attestation, addDays, splitPhone, splitStreet, adDays, dayCode, attendanceAmount, hoursFor };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.DaycareForms = api;
})(typeof window !== 'undefined' ? window : globalThis);
